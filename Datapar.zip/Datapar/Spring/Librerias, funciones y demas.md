
# A conocer

- AtomicLong(); 
	- **java.util.concurrent.atomic.AtomicLong**

- @RestController, @GetMapping, @RequestParam, @PostMapping, @RequestMapping(method=---)
	- **org.springframework.web.bind.annotation.*

- String.format(template, value); 

- @JsonIgnoreProperties(ignoreUnknown = true)

	


[[Spring Boot]]