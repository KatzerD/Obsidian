Es muy parecido el contexto Singleton, prácticamente se utilizan como lo mismo.
Su diferencia es que es un Singleton que se guarda en el contexto Servlet y no en el ApplicationContext.