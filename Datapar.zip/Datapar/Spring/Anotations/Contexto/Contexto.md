Los contextos o Scope de los componentes es el alcance que tienen sus instancias creadas. Por defecto son del tipo Singleton.

Para aplicaciones Web existen 3 tipos de contextos
- [[@ApplicationScope]]
- [[@SessionScope]]
- [[@RequestScope]]