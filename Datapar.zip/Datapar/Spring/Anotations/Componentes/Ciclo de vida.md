Todos los componentes tienen un ciclo de vida en sistema, se crean, se utilizan/modifican y se destruyen.
Dos anotaciones para ejecutar funciones según el ciclo de vida del componente son:
- [[@PostConstruct]]
- [[@PreDestroy]]
- [[@PrePersist]]
- [[@PreUpdate]]
- [[@PreDestroy_]]
- [[@PreRemove]]



Para estas funciones es importante entender lo que es el [[Contexto]] de la instancia.
