
Mediante el desacoplamiento con una interfaz, esta interfaz puede ser inyectada en un
- Atributo
- Constructor
- Setter
