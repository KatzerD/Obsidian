
El fundamento de Spring Boot es el uso de anotaciones como `@Component`, `@Controller`, etc.

Estas anotaciones son manejadas por el centro de dependencias de Spring.

[[Inyección de Dependencias]]
[[Carga&Redirect&Forward]]
[[Base de datos]]
[[Interceptores]]


[[Spring Security]]