Se coloca en la tabla que tiene relación de muchas a muchos

[[mappedBy=..., fetch=... , cascade=...]]