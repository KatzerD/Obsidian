Es un estereotipo de @Component.

Garantiza que nuestros DAOs o repositorios tengan una adecuada traducción de errores/excepciones.

Permite el soporte para el escáner de componentes DAOs/Repositorios y que estos puedan ser encontrados y configurados sin tener que ser definidos en el XML de Contexto.
