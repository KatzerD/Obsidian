Es usado para validar que los campos de tipo string no estén vacíos ``" "``

