Elimina la entidad.
