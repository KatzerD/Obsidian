``find(Class<T> entity, Object primaryKey)``
Busca la entidad a través de su clave primaria