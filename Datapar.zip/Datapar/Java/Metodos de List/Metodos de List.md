
- .size()
- .isEmpty()

## Crear una lista
``List<Tipo> lista = new ArrayList<>();``

``List<Tipo> lista = Arrays.asList(new (...), new (...), new (...))`` Para rellenar una lista pasando los valores entre comas

[[Java]]