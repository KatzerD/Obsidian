Es una tecnologia de persistencia de datos para los DAO, como lo son JDBC, Hibernate, JPA usando API Spring Data con la interface CrudRepository.

[[Java]]
[[DAO]]
[[Entidades]]