![[Pasted image 20231115144258.png]]

[[Arquitectura]]