[Diagrama de Classes - Dolphinx - Confluence (atlassian.net)](https://datapar.atlassian.net/wiki/spaces/DOL/pages/2130013/Diagrama+de+Classes)

[[Arquitectura]]