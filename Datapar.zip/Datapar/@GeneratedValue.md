`@GeneratedValue(strategy = GenerationType.)`

La estrategia puede ser de tipo `IDENTITY`, `SEQUENCE`, etc.