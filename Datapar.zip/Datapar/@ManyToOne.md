Se coloca en la tabla que tiene relación de muchas a uno, por ejemplo una factura puede tener muchos clientes.
[[mappedBy=..., fetch=... , cascade=...]]