# Vistas para REST
REST es una representación de un flujo de datos (transferencia de estado representacional). Básicamente para compartir información/datos e integrar servicios en otras aplicaciones de manera estándar.
[[Convertir a XML]]
[[Convertir a JSON]]
[[Convertir API-REST]]