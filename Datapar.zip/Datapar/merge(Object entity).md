Actualiza las modificaciones en una entidad devolviendo un objeto entity manejado por el contexto Doctrine.
