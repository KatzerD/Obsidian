Envuelve el contenido del método en una transacción.

`@Transactional(readOnly=true)` cuando es una consulta.
