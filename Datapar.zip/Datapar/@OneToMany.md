Se coloca en la tabla que tiene relación de uno a muchos, por ejemplo una un cliente puede tener muchas facturas
[[mappedBy=..., fetch=... , cascade=...]]


# Relaciones unidireccionales
En relaciones unidireccionales en lugar de utilizar el `mappedBy` se utiliza otra anotación llamada [[@JoinColumn]]