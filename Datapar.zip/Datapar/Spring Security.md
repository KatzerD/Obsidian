

Spring Security provee características de seguridad para aplicaciones empresariales Java EE.

Maneja componentes de  "Autenticación" y "Autorización".

# Características
- Configuración simple
- Esquema de base de datos
- Autenticación en memoria y en Base de Datos
- Roles y Usuarios
- Autorización ACL
- Form y Login
- Logout

# Clase para configuración de la seguridad
[[Iniciar Spring Security - SpringSecurityConfig]]