[[@JsonIgnore]]
[[@JsonIgnoreProperties]]
[[@JsonManagedReference]]
[[@JsonBackReference]]