Crear un archivo `messages.properties`
La sintaxis es ``ReglaDeValidacion.NombreClaseMinuscula.NombreAtributo``

```properties
NotEmpty.cliente.nombre= El nombre del cliente es requerido

NotEmpty.cliente.apellido= El apellido del cliente es requerido

NotEmpty.cliente.email= El email es requerido

Email.cliente.email= La direccion de correo no es valida

typeMismatch.cliente.createAt= Formato de fecha no es valido, debe ser yyyy-mm-dd
```
