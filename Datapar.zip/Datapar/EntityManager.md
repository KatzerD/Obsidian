Se encarga  de manejar las clases de entidades, el ciclo de vida, las persiste, puede realizar consultas, es decir, todas las operaciones a la base de datos a nivel de objeto, a través de los Entitys.

Sus métodos mas importantes son:

- [[persist(Object entity)]]
- [[merge(Object entity)]]
- [[remove(Object entity)]]
- [[find(Class entity, Object primaryKey)]]