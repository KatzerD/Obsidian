``@GetMapping(value="/index")`` == ``@GetMapping("/index")``

``@GetMapping({"/index", "/", "/home"})`` Mas de una ruta

`@GetMapping("/form/{id}")` Interceptar parámetros en la url