Colocando esta anotación en la clase de configuración SpringSecurityConfig 

``@EnableMethodSecurity(securedEnabled = true, prePostEnabled = true)``

habilitamos la asignación de autorizaciones desde el controlador con las anotaciones

- [[@Secured]]
- [[@PreAuthorize]] 
