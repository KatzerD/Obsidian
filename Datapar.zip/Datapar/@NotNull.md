Se utiliza para validar que los campos no sean Nulos, se utiliza en fechas por ejemplo.

IMPORTANTE
Si la fecha es generada automáticamente con ``prePersist()`` no agregar la anotación NotNull