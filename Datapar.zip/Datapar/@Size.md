Para definir un tamaño mínimo y máximo al campo
``@Size(min=4, max=12)``